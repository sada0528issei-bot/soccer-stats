# -*- coding: utf-8 -*-
"""
東京都大学サッカー連盟 出場時間ランキング 自動集計スクリプト
=====================================================

【できること】
  「試合日程・結果」ページを開き、全試合を自動でクリックしながら
  各選手の出場時間を計算し、CSVに書き出します。

【事前準備(パソコンで1回だけ)】
  pip install playwright beautifulsoup4
  playwright install chromium

【実行方法】
  python scrape_stats.py

【出力される2つのファイル】
  raw_playing_time.csv      … 試合ごとの生データ(選手×試合の1行1レコード)
  playing_time_ranking.csv  … 選手ごとに集計した出場時間ランキング

※ このスクリプトはネットワークアクセスが必要です。
   Claudeのサンドバック環境ではなく、ご自身のパソコンで実行してください。
"""

import csv
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

# ============================================================
# 設定(必要に応じて変更してください)
# ============================================================

# 集計したいシーズンのURL(fy=年度, srys=シリーズID)
SCHEDULE_URL = "https://www.f-togakuren.com/match?fy=2026&srys=698c64e733ddad528a1e0452"

# 1試合分の行を特定するセレクタ(検証で確認したクラスの組み合わせ)
MATCH_ROW_SELECTOR = "div.columns.is-multiline.is-gapless.is-mobile:has(.match-result)"

# 初回はブラウザ画面を表示して動作確認するのがおすすめです(True=非表示/高速, False=表示/デバッグ用)
HEADLESS = False


# ============================================================
# 出場時間の計算ロジック(サンプルデータで検証済み)
# ============================================================

def parse_time(time_str: str, entry_type: str) -> int:
    """entry_type: 'out'=先発から交代(▼), 'in'=途中出場(▲)"""
    if time_str == "HT":
        base = 45
    elif "+" in time_str:
        base = 90  # 90+X(アディショナルタイム)は90扱い
    else:
        base = int(time_str)

    if entry_type == "out":
        return base
    else:  # in
        return max(90 - base, 0)


def parse_team_order_table(table_div):
    """1つの team-order-table (先発 or 控え) から左右2チーム分の選手リストを返す"""
    rows = table_div.find_all("div", recursive=False)
    left, right = [], []
    for row in rows:
        cols = row.find_all("div", recursive=False)
        if len(cols) != 2:
            continue
        for side, col in zip((left, right), cols):
            cells = col.find_all("div", recursive=False)
            if len(cells) < 3:
                continue
            pos = cells[0].get_text(strip=True)
            if pos not in ("GK", "DF", "MF", "FW"):
                continue  # ヘッダー行や空セルはスキップ

            name_cell = cells[1]
            num_span = name_cell.find("span")
            number = num_span.get_text(strip=True) if num_span else ""
            full_text = name_cell.get_text(strip=True)
            name = full_text[len(number):].strip() if number and full_text.startswith(number) else full_text

            change_span = cells[2].find("span", class_="change")
            change_mark, change_time = None, None
            if change_span:
                mark_tag = change_span.find("span", class_="has-text-danger")
                change_mark = mark_tag.get_text(strip=True) if mark_tag else None
                time_spans = change_span.find_all("span")
                change_time = time_spans[-1].get_text(strip=True) if time_spans else None

            side.append({
                "number": number,
                "name": name,
                "position": pos,
                "change_mark": change_mark,
                "change_time": change_time,
            })
    return left, right


def build_playing_time(starters_pair, bench_pair):
    results = []
    for team_starters, team_bench in zip(starters_pair, bench_pair):
        team_players = []
        for p in team_starters:
            if p["change_mark"] == "▼" and p["change_time"]:
                minutes = parse_time(p["change_time"], "out")
            else:
                minutes = 90
            team_players.append({**p, "minutes_played": minutes, "status": "先発"})
        for p in team_bench:
            if p["change_mark"] == "▲" and p["change_time"]:
                minutes = parse_time(p["change_time"], "in")
            else:
                minutes = 0
            team_players.append({**p, "minutes_played": minutes, "status": "控え"})
        results.append(team_players)
    return results


def parse_game_detail(html: str):
    """1試合分の game-detail の outerHTML から、両チームの出場時間データを算出する"""
    soup = BeautifulSoup(html, "html.parser")

    team_names = [d.get_text(strip=True) for d in soup.select(".team-name-score .team-name")]
    tables = soup.select(".team-order-table")
    if len(team_names) != 2 or len(tables) < 2:
        return None  # 想定外の構造(要目視確認)

    starter_left, starter_right = parse_team_order_table(tables[0])
    bench_left, bench_right = parse_team_order_table(tables[1])
    teams = build_playing_time((starter_left, starter_right), (bench_left, bench_right))

    date_el = soup.select_one(".mx-2")
    match_date = date_el.get_text(strip=True) if date_el else ""

    records = []
    for team_name, players in zip(team_names, teams):
        for p in players:
            records.append({
                "date": match_date,
                "team": team_name,
                "number": p["number"],
                "name": p["name"],
                "position": p["position"],
                "minutes_played": p["minutes_played"],
                "status": p["status"],
            })
    return records


# ============================================================
# ブラウザ自動操作で全試合を巡回
# ============================================================

def scrape_all_matches():
    all_records = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=HEADLESS)
        page = browser.new_page()
        page.goto(SCHEDULE_URL, wait_until="networkidle")
        page.wait_for_selector(".match-result", timeout=15000)

        rows = page.locator(MATCH_ROW_SELECTOR)
        count = rows.count()
        print(f"{count} 件の試合を検出しました")

        prev_html = None
        for i in range(count):
            row = rows.nth(i)
            row.scroll_into_view_if_needed()
            row.click()
            page.wait_for_timeout(400)

            detail = page.locator(".game-detail")
            try:
                detail.wait_for(state="visible", timeout=5000)
            except Exception:
                print(f"  [{i + 1}/{count}] 詳細が開けませんでした。スキップします")
                continue

            html = detail.evaluate("el => el.outerHTML")
            if html == prev_html:
                # 前の試合と内容が同じ=描画がまだ切り替わっていない可能性があるので少し待って再取得
                page.wait_for_timeout(400)
                html = detail.evaluate("el => el.outerHTML")
            prev_html = html

            records = parse_game_detail(html)
            if records:
                all_records.extend(records)
                print(f"  [{i + 1}/{count}] 取得完了({len(records)}名分)")
            else:
                print(f"  [{i + 1}/{count}] 想定外の構造だったためスキップしました(要確認)")

        browser.close()

    return all_records


# ============================================================
# 集計 & CSV出力
# ============================================================

def save_results(all_records):
    # 試合ごとの生データ
    with open("raw_playing_time.csv", "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f, fieldnames=["date", "team", "number", "name", "position", "minutes_played", "status"]
        )
        writer.writeheader()
        writer.writerows(all_records)

    # 選手ごとに集計(累計出場時間・出場試合数)
    summary = {}
    for r in all_records:
        key = (r["team"], r["number"], r["name"])
        if key not in summary:
            summary[key] = {"team": r["team"], "number": r["number"], "name": r["name"],
                             "total_minutes": 0, "appearances": 0}
        summary[key]["total_minutes"] += r["minutes_played"]
        if r["minutes_played"] > 0:
            summary[key]["appearances"] += 1

    ranking = sorted(summary.values(), key=lambda x: -x["total_minutes"])

    with open("playing_time_ranking.csv", "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["team", "number", "name", "total_minutes", "appearances"])
        writer.writeheader()
        writer.writerows(ranking)

    print(f"\n完了: raw_playing_time.csv / playing_time_ranking.csv に書き出しました")
    print(f"合計 {len(all_records)} 件の選手×試合データを集計しました")


if __name__ == "__main__":
    records = scrape_all_matches()
    if records:
        save_results(records)
    else:
        print("データを取得できませんでした。MATCH_ROW_SELECTOR の見直しが必要かもしれません。")
